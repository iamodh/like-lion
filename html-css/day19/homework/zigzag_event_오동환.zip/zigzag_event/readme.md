https://www.figma.com/design/Yc3Vek0CDh5LAOY2qIGVoq/ZIGZAG/duplicate

START YOUR
PORTFOLIO
PROJECT

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled

Rest
Take a rest
- It has survived not only five centuries.
- Why do we use it?
- Contrary to popular belief, Lorem Ipsum is not simply random text. It has root.

Craft
Build something
- There are many variations of passages of Lorem Ipsum available.
- If you are going to use a passage of Lorem Ipsum.
- The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.

Scrap
Reference
- Once is therefore always free form repetition, injected humor, or non-characterisic words etc.
- Predefined chunks as necessary, making this the first true generator on the internet.
- Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form.


CALENDAR AND
EVENT TOOLS.

+ Add to Calendar

===== 
    HTML CSS JavaScript
-----
    Digital Workplace Experience
-----
    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.
-----
    SOLDOUT
===== 

===== 
    AR VR Headsets
-----
    Augmented World Expo 2022
-----
    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
-----
    + More People
===== 

===== 
    Photoshop Illustrator
----
    Adobe Summit
----
    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley.
----
    + More People
===== 

