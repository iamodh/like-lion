"use strict";

let result = document.getElementById("result");
let data = {};

let username = document.getElementById("username");
username.addEventListener("blur", (e) => {
  data.username = e.target.value;
});

let phone = document.getElementById("phone");
phone.addEventListener("blur", (e) => {
  data.phone = e.target.value;
});

let job = document.getElementById("job");
job.addEventListener("change", (e) => {
  data.job = e.target.value;
});

let join = document.getElementById("join");
join.addEventListener("click", (e) => {
  e.preventDefault();
  result.innerHTML = `이름: ${data.username}<br/>전화번호: ${data.phone}<br/>직업: ${data.job}`;
});

let reset = document.getElementById("reset");
reset.addEventListener("click", () => {
  result.innerHTML = "";
  data = {};
});
